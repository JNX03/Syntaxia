import SwiftUI
                                                                            
@main
struct MyApp: App {
    @State private var showIntro = false
    @State private var showPlayground = false
    @State private var showLearn = false 
    @State private var showPractice = false
    
    var body: some Scene {
        WindowGroup {
            ZStack {
                if showPlayground {
                    Playground()
                        .transition(.opacity)
                } else if showIntro {
                    Intro()
                        .transition(.opacity)
                } else if showPractice {
                    Practice()
                        .transition(.opacity)
                } else if showLearn {
                    LearningView()
                        .transition(.opacity)
                } else {
                    ContentView(showIntro: $showIntro,
                                showPlayground: $showPlayground,
                                showLearn: $showLearn,
                                showPractice: $showPractice)
                    .transition(.opacity)
                }
            }
        }
    }
}
