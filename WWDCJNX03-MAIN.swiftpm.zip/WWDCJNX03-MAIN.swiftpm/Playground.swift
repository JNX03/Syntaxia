import SwiftUI
import UniformTypeIdentifiers
import AVFoundation
import Vision

struct Playground: View {
    @Binding var showPlayground: Bool
    @StateObject var viewModel = NodeEditorViewModel()
    @State private var terminalOutput: String = ""
    @State private var generatedCode: String = ""
    @State private var handTrackingEnabled: Bool = false
    @State private var showTutorial: Bool = true
    @StateObject private var handManager = HandTrackingManager()
    var body: some View {
        ZStack {
            VStack(spacing: 0) {
                HStack {
                    Button("Back") {
                        showPlayground = false
                    }
                    .padding()
                    .background(Color.gray.opacity(0.7))
                    .cornerRadius(8)
                    Spacer()
                }
                HStack(spacing: 0) {
                    NodeCatalog(viewModel: viewModel)
                    ZStack {
                        NodeEditorCanvas(viewModel: viewModel)
                        if handTrackingEnabled {
                            HandTrackingOverlay(handManager: handManager, viewModel: viewModel)
                        }
                    }
                    CodeTabView(generatedCode: generatedCode)
                }
                TerminalView(output: terminalOutput)
                HStack {
                    Button("Run Code") {
                        terminalOutput = viewModel.runCode()
                    }
                    .padding()
                    Button(handTrackingEnabled ? "Disable Hand Tracking" : "Enable Hand Tracking") {
                        handTrackingEnabled.toggle()
                    }
                    .padding()
                    Spacer()
                }
                .background(LinearGradient(gradient: Gradient(colors: [Color(red: 0.15, green: 0.15, blue: 0.18),
                                                                       Color(red: 0.10, green: 0.10, blue: 0.12)]),
                                           startPoint: .top, endPoint: .bottom))
            }
            .frame(minWidth: 900, minHeight: 750)
            .onChange(of: viewModel.nodes) { _ in
                generatedCode = viewModel.generateCode()
            }
            .onChange(of: viewModel.connections) { _ in
                generatedCode = viewModel.generateCode()
            }
            if showTutorial {
                TutorialView() {
                    showTutorial = false
                }
            }
        }
    }
}

